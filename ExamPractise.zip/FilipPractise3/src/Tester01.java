
public class Tester01 {

	public static void main(String[] args) {
		Customer c1 = new Customer("Jim", "Brown", "12/12/65");
		System.out.println(c1.toString());

	}

}

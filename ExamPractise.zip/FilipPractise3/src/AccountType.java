
public enum AccountType {
	PERSONAL, BUSINESS;
}
